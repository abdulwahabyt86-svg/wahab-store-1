WAHAB STORE - FLASK VERSION

IMPORTANT:
Your old screenshot was caused by opening templates/index.html with VS Code Live Server on port 5500.
The corrected HTML now uses /statics/style.css and /statics/script.js, and Flask serves the same /statics URL.

RECOMMENDED:
1. Open this folder in VS Code.
2. Open Command Prompt in this folder.
3. Run: python -m pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000/
6. Do NOT open templates/index.html directly.

You can also double-click run.bat after Python is installed.

Admin:
Username: wahab
Password: khan804

Static files:
statics/style.css
statics/script.js

The project keeps the dark/orange/yellow Wahab Store styling and the cart Buy Now popup styling.


PRODUCT VISIBILITY / RAILWAY DEPLOYMENT
---------------------------------------
Products are now saved through the Flask server API instead of only browser localStorage.
This means a product added from the Admin Panel is shared with all visitors.

IMPORTANT FOR RAILWAY:
The JSON data files are stored in the "data" directory. Railway's normal container
filesystem is not guaranteed to survive redeploys/restarts. To keep products/orders
permanently, attach a Railway Volume and mount it at a persistent directory, then
set the environment variable:

WAHAB_DATA_DIR=/app/data

The project already supports WAHAB_DATA_DIR. If your Railway service uses /app as
the project directory, mount the Volume at /app/data.

After deploying this version:
1. Open Admin Panel and add a test product.
2. Open the store in an incognito/private window or another device.
3. The same product should appear for that visitor.
4. For permanent data across Railway redeploys/restarts, make sure the Volume is attached.
